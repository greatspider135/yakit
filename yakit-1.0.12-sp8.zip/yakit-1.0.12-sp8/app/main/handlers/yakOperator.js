const {ipcMain} = require("electron");

module.exports = (win, getClient) => {

}